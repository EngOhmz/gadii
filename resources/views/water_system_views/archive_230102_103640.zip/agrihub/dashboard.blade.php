@extends('layouts.master')

@section('content')

<section class="section">
    <div class="row ">

<div class="col-lg-3">
									<!-- Today's revenue -->
									<div class="card bg-primary text-white">
										<div class="card-body">
											<div class="d-flex"><h3 class="font-weight-semibold mb-0">{{isset($cards)? number_format($cards) : '0'}}</h3></div>
						                	<div >Cards</div>
												
										</div>
									</div>
                                                                  </div>
									<!-- /today's revenue -->

                                                      <!-- Today's revenue -->
                                                          <div class="col-lg-3">

									<div class="card bg-pink text-white">
										<div class="card-body">
											<div class="d-flex"><h3 class="font-weight-semibold mb-0">{{isset($customer)? number_format($customer) : '0.00'}}</h3></div>
												
						                	<div>Customers</div>
												
										</div>
									</div></div>
									<!-- /today's revenue -->
                                                                    
                                                                 <!-- Members online -->
								<div class="col-lg-3">
									<div class="card bg-teal text-white">
										<div class="card-body">
											<div class="d-flex"><h3 class="font-weight-semibold mb-0">{{isset($meter)? number_format($meter) : '0.00'}}</h3></div>
						                	
						                	<div>Meters</div>
												
										</div>
									</div>									<!-- /members online -->

								</div>
                                                                 
								<div class="col-lg-3">
									<!-- Current server load -->
									<div class="card bg-dark text-white">
										<div class="card-body">
											<div class="d-flex"><h3 class="font-weight-semibold mb-0">{{isset($revenue)? number_format($revenue,2) : '0.00'}}</h3></div>
						                	<div>Revenue</div>
										</div>
									</div>
									<!-- /current server load -->
								</div>
                                                             

       
    </div>
    <div class="row ">

        <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <h5 class="font-15">Customer Registered and Meter Installation Combined Graph</h5>
                                    <div id="monthly_actual_expected_data" class="chart" style="height: 320px;">
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="{{ asset('assets/amcharts/amcharts.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/amcharts/serial.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/amcharts/pie.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/amcharts/themes/light.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/amcharts/plugins/export/export.min.js') }}" type="text/javascript"></script>
    <script>
    AmCharts.makeChart("monthly_actual_expected_data", {
        "type": "serial",
        "theme": "light",
        "autoMargins": true,
        "marginLeft": 30,
        "marginRight": 8,
        "marginTop": 10,
        "marginBottom": 26,
        "fontFamily": 'Open Sans',
        "color": '#888',

        "dataProvider":{!! $monthly_actual_expected_data !!},
        "valueAxes": [{
            "axisAlpha": 0,

        }],
        "startDuration": 1,
        "graphs": [{
            "balloonText": "<span style='font-size:13px;'>[[title]] in [[category]]:<b> [[value]]</b> [[additional]]</span>",
            "bullet": "round",
            "bulletSize": 8,
            "lineColor": "#370fc6",
            "lineThickness": 4,
            "negativeLineColor": "#0dd102",
            "title": "Customer",
            "type": "smoothedLine",
            "valueField": "customer"
        }, {
            "balloonText": "<span style='font-size:13px;'>[[title]] in [[category]]:<b> [[value]]</b> [[additional]]</span>",
            "bullet": "round",
            "bulletSize": 8,
            "lineColor": "#d1655d",
            "lineThickness": 4,
            "negativeLineColor": "#d1cf0d",
            "title": "Meters",
            "type": "smoothedLine",
            "valueField": "meter"
        }],
        "categoryField": "month",
        "categoryAxis": {
            "gridPosition": "start",
            "axisAlpha": 0,
            "tickLength": 0,
            "labelRotation": 30,

        },
        "export": {
            "enabled": true,
            "libs": {
                "path": "{{asset('assets/amcharts/plugins/export/libs')}}/"
            }
        },
        "legend": {
            "position": "bottom",
            "marginRight": 100,
            "autoMargins": false
        },


    });
    </script>



</section>

@endsection