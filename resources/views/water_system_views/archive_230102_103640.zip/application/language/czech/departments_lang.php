<?php
$lang['menu_permission'] = 'Povolení Menu';
$lang['module'] = 'Oddělení infromation úspěšné aktualizaci';
$lang['department_update'] = 'Oddělení infromation úspěšné aktualizaci';
$lang['designation_info_deleted'] = 'Označení infromation úspěšně smazán';
$lang['no_designation_create_yet'] = 'Ne Označení Vytvořit dosud';
$lang['department_already_used'] = 'Oddělení informačních již využily';
$lang['undefined_department'] = 'nedefinovaný Oddělení';
$lang['activity_update_a_department'] = 'Oddělení aktualizace';
$lang['activity_delete_a_department'] = 'vypouští se Oddělení';
$lang['activity_delete_a_designation'] = 'Označení ';


/* End of file departments_lang.php */
/* Location: ./application/language/czech/departments_lang.php */
