<?php
$lang['bugs'] = 'Hmyz';
$lang['bugs_email'] = 'chyby ';
$lang['bug_assigned'] = ' Účelově';
$lang['bug_comments'] = 'Komentáře';
$lang['bug_attachment'] = 'Aktualizováno';
$lang['bug_updated'] = 'Aktualizováno';
$lang['bug_reported'] = 'Hlášeny';
$lang['update_bug'] = 'Chyby infromation úspěšně aktualizováno';
$lang['save_bug'] = 'Chyby infromation Úspěšně uloženo';
$lang['delete_timesheet'] = 'Časovač infromation úspěšně ';
$lang['bug_deleted'] = 'Chyby infromation úspěšně';
$lang['activity_delete_tasks_timesheet'] = 'Úkoly časový rozvrh vypouští';
$lang['activity_update_task_timesheet'] = 'Úkoly Timesheet Aktualizováno';
$lang['activity_update_bug'] = 'Aktivita Aktualizovat Chyby';
$lang['activity_new_bug_comment'] = 'Chyby činnost nové komentáře';
$lang['activity_bug_attachfile_deleted'] = 'Chyby Aktivita Příloha byla smazána';
$lang['activity_new_bug_attachment'] = 'Chyby Aktivita připojit nové soubory';
$lang['activity_bug_deleted'] = 'Chyby Aktivita';
$lang['activity_new_bug'] = 'Aktivita nové chyby přidáno';
$lang['all_bugs'] = 'Všechny Chyby';
$lang['new_bugs'] = 'Nové Chyby';
$lang['bug_status'] = 'chyba Stav';
$lang['bug_title'] = 'Bug Název';
$lang['resolved'] = 'vyřešeno';
$lang['update_on'] = 'Aktuální informace o';
$lang['bug_details'] = 'chyby Podrobnosti';


/* End of file bugs_lang.php */
/* Location: ./application/language/czech/bugs_lang.php */
