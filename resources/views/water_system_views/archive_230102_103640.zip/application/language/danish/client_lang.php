<?php
$lang['client_list'] = 'Navn';
$lang['all_client'] = 'Navn';
$lang['name'] = 'Navn';
$lang['client'] = 'Navn';
$lang['clients'] = 'Navn';
$lang['client_status'] = 'Navn';
$lang['select'] = 'Navn';
$lang['manage_client'] = 'Navn';
$lang['clients_registration'] = 'Navn';
$lang['clients_registered'] = 'Navn';
$lang['client_registered_successfully'] = 'Navn';
$lang['activity_added_new_company'] = 'Navn';
$lang['activity_update_company'] = 'Navn';
$lang['activity_update_contact'] = 'Navn';
$lang['activity_added_new_contact'] = 'Navn';
$lang['activity_deleted_contact'] = 'Navn';
$lang['delete_contact'] = 'Navn';
$lang['activity_deleted_client'] = 'Navn';
$lang['delete_client'] = 'Navn';
$lang['select_type'] = 'Navn';
$lang['client_contact'] = 'Navn';
$lang['hosting'] = 'Navn';
$lang['converted_from'] = 'Navn';
$lang['without_converted'] = 'Navn';
$lang['converted_client'] = 'Navn';


/* End of file client_lang.php */
/* Location: ./application/language/danish/client_lang.php */
