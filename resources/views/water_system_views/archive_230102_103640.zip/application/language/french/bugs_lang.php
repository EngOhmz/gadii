<?php
$lang['bugs'] = ' Bogues';
$lang['bugs_email'] = ' Bugs Email';
$lang['bug_assigned'] = 'Bug Assigné';
$lang['bug_comments'] = ' Bug Commentaires';
$lang['bug_attachment'] = ' Bug Attachment';
$lang['bug_updated'] = 'Bug Mise à jour';
$lang['bug_reported'] = ' Bug Rapporté';
$lang['update_bug'] = ' Bugs infromation mis à jour avec succès';
$lang['save_bug'] = ' Bugs infromation sauvé avec succès';
$lang['delete_timesheet'] = 'infromation Minuteur avec succès supprimé';
$lang['bug_deleted'] = ' Bugs infromation avec succès supprimé';
$lang['activity_delete_tasks_timesheet'] = ' Tâches Timesheet supprimé';
$lang['activity_update_task_timesheet'] = 'Tâches Timesheet Mise à jour';
$lang['activity_update_bug'] = 'Mise à jour d\'activité Bugs';
$lang['activity_new_bug_comment'] = ' Bugs Activité Nouveaux Commentaires';
$lang['activity_bug_attachfile_deleted'] = ' Bugs Activity Attachment supprimé';
$lang['activity_new_bug_attachment'] = ' Bugs d\'activité Joindre un nouveau fichier';
$lang['activity_bug_deleted'] = ' Bugs d\'activité supprimés';
$lang['activity_new_bug'] = ' Activité Nouveaux Bugs Ajouté';
$lang['all_bugs'] = ' Tous les Bugs';
$lang['new_bugs'] = ' Nouveaux Bugs';
$lang['bug_status'] = ' Bug Status';
$lang['bug_title'] = 'Bug Titre';
$lang['resolved'] = 'Résolu';
$lang['update_on'] = ' Mise à jour sur';
$lang['bug_details'] = ' Bugs Détails';


/* End of file bugs_lang.php */
/* Location: ./application/language/french/bugs_lang.php */
