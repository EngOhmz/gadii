@extends('layouts.master')


@section('content')
<section class="section">
    <div class="section-body">
        <div class="row">
            <div class="col-12 col-sm-6 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Journal Entry</h4>
                    </div>
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="myTab2" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link @if(empty($id)) active show @endif" id="home-tab2" data-toggle="tab"
                                    href="#home2" role="tab" aria-controls="home" aria-selected="true">Journal Entry
                                    List</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link @if(!empty($id)) active show @endif" id="profile-tab2"
                                    data-toggle="tab" href="#profile2" role="tab" aria-controls="profile"
                                    aria-selected="false">New Journal Entry</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link  " id="importExel-tab"
                                    data-toggle="tab" href="#importExel" role="tab" aria-controls="profile"
                                    aria-selected="false">Import</a>
                            </li>

                        </ul>
                        <div class="tab-content tab-bordered" id="myTab3Content">
                            <div class="tab-pane fade @if(empty($id)) active show @endif" id="home2" role="tabpanel"
                                aria-labelledby="home-tab2">
                                <div class="table-responsive">
                               
                                  <table class="table datatable-button-html5-basic" id="itemsDatatable">
                                       <thead>
                                            <tr>
                                                <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0"
                                                    rowspan="1" colspan="1"
                                                    aria-label="Browser: activate to sort column ascending"
                                                    style="width: 28.531px;">#</th>

                                                <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0"
                                                    rowspan="1" colspan="1"
                                                    aria-label="Platform(s): activate to sort column ascending"
                                                    style="width: 106.484px;">Account Codes</th>
                                                <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0"
                                                    rowspan="1" colspan="1"
                                                    aria-label="Platform(s): activate to sort column ascending"
                                                    style="width: 186.484px;">Account Name</th>
                                                <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0"
                                                    rowspan="1" colspan="1"
                                                    aria-label="Engine version: activate to sort column ascending"
                                                    style="width: 141.219px;">Debit</th>
                                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0"
                                                    rowspan="1" colspan="1"
                                                    aria-label="Engine version: activate to sort column ascending"
                                                    style="width: 141.219px;">Credit</th>
                                                <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0"
                                                    rowspan="1" colspan="1"
                                                    aria-label="CSS grade: activate to sort column ascending"
                                                    style="width: 98.1094px;">Date</th>
                                            </tr>
                                        </thead>
                                         <tbody>
                                           

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade @if(!empty($id)) active show @endif" id="profile2" role="tabpanel"
                                aria-labelledby="profile-tab2">

                                <div class="card">
                                    <div class="card-header">
                                        <h5>Create Journal Entry</h5>
                                     
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-sm-12 ">
                                            
                                                {{ Form::open(['url' => url('accounting/manual_entry/store')]) }}
                                                @method('POST')
                                            

                                              
                                        
                                           <div class="form-group row">
                                                    <label class="col-lg-2 col-form-label">Date <span class="required"> * </span> </label>
                                                    <div class="col-lg-8">
                                                        <input type="date" name="date" required {{Auth::user()->can('edit-date') ? '' : ''}}
                                                            placeholder=""
                                                            value="{{ isset($data) ? $data->date : date("Y-m-d")}}"
                                                           
                                                            class="form-control date-picker">
                                                    </div>
                                                </div>
                                               
                                        
                                                 <div class="form-group row">
                                                <label class="col-lg-2 col-form-label">Branch</label>
                                                   <div class="col-lg-8">
                                                    <select class="form-control m-b" name="branch_id" id="branch_id" >
                                                    <option value="" selected>Select Branch</option>
                                                    @if(isset($branch))
                                                    @foreach($branch as $row)
                                                    <option value="{{ $row->id }}">{{ $row->name }}</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                                    </div>
                                                </div>
                                              
                                                  


                                            
                                                
                                                <hr>
                                             <button type="button" name="add" class="btn btn-success btn-xs add"><i class="fas fa-plus"> </i> Add item</button><br>
                                             
                                             <div class=""> <p class="form-control-static errors" id="errors" style="text-align:center;color:red;"></p>   </div>
                        
                                              <br>
    <div class="table-responsive">
<table class="table table-bordered" id="cart">
            <thead>
              <tr>
                <th>Type <span class="required"> * </span</th>
                <th>Account <span class="required"> * </span> </th>
                 <th>Debit Amount</th>
                 <th>Credit Amount</th>
                <th>Notes</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
                                    

</tbody>

<tfoot>
  <tr>
  <td></td>
<td><span class="bold">Total</span> </td>
<td class="total_debit" id="total"></td>
 <td class="total_credit" id="total"></td>
 <td colspan="3"></td>
</tr>
 <tr>
  <td></td>
<td><span class="bold">Difference</span> </td>
<td class="total_diff" colspan="5"></td>
</tr>
                                                       
        </tfoot>

</table>
</div>
<br>


                                                <div class="form-group row">
                                                    <div class="col-lg-offset-2 col-lg-12">
                                                         @if(!@empty($id))
                                                        <button class="btn btn-sm btn-primary float-right m-t-n-xs"
                                                            data-toggle="modal" data-target="#myModal"
                                                            type="submit">Update</button>
                                                        @else
                                                        <button class="btn btn-sm btn-primary float-right save"
                                                            type="submit" id="save">Save</button>
                                                        @endif
                                                    </div>
                                                </div>
                                                {!! Form::close() !!}
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade @if(!empty($id)) active show @endif" id="importExel" role="tabpanel"
                            aria-labelledby="importExel-tab">

                            <div class="card">
                                <div class="card-header">
                                     <form action="{{ route('sample') }}" method="POST" enctype="multipart/form-data">
                                        @csrf
                                        <button class="btn btn-success">Download Sample</button>
                                        </form>
                                 
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-12 ">
                                            <div class="container mt-5 text-center">
                                                <h4 class="mb-4">
                                                 Import Excel & CSV File   
                                                </h4>
                                                <form action="{{ route('import') }}" method="POST" enctype="multipart/form-data">
                                            
                                                    @csrf
                                                    <div class="form-group mb-4">
                                                        <div class="custom-file text-left">
                                                            <input type="file" name="file" class="form-control" id="customFile" required>
                                                        </div>
                                                    </div>
                                                    <button class="btn btn-primary">Import Journal</button>
                                          
                                        </form>
                                       
                                    </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>



@endsection

@section('scripts')
<link rel="stylesheet" href="{{ asset('assets/datatables/css/jquery.dataTables.css') }}">
<link rel="stylesheet" href="{{ asset('assets/datatables/css/buttons.dataTables.min.css') }}">

<script src="{{asset('assets/datatables/js/jquery.dataTables.js')}}"></script>
<script src="{{asset('assets/datatables/js/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('assets/datatables/js/jszip.min.js')}}"></script>
<script src="{{asset('assets/datatables/js/pdfmake.min.js')}}"></script>
<script src="{{asset('assets/datatables/js/vfs_fonts.js')}}"></script>
<script src="{{asset('assets/datatables/js/buttons.html5.min.js')}}"></script>
<script src="{{asset('assets/datatables/js/buttons.print.min.js')}}"></script>


<script>
$(function() {
    let urlcontract = "{{ route('journal.manual') }}";
    $('#itemsDatatable').DataTable({
        processing: true,
        serverSide: true,
        searching: true,
       "dom": 'lBfrtip',

        buttons: [
          {extend: 'copyHtml5',title: 'JOURNAL ENTRY LIST ', footer: true},
           {extend: 'excelHtml5',title: 'JOURNAL ENTRY LIST' , footer: true},
           {extend: 'csvHtml5',title: 'JOURNAL ENTRY LIST' , footer: true},
            {extend: 'pdfHtml5',title: 'JOURNAL ENTRY LIST', footer: true, customize: function(doc) {
doc.content[1].table.widths = [ '8%', '20%', '32%', '14%', '14%','12%'];
}},
            {extend: 'print',title: 'JOURNAL ENTRY LIST' , footer: true}

                ],
        
        
       
        columns: [
            {
                data: 'DT_RowIndex',
                name: 'DT_RowIndex',
                orderable: false,
                searchable: false
            },
            {
                data: 'account_code',
                name: 'account_code'
            },
            {
                data: 'account_name',
                name: 'account_name'
            },
            {
                data: 'debit',
                name: 'debit'
            },
            {
                data: 'credit',
                name: 'credit'
            },
            {
                data: 'date',
                name: 'date'
            },

           
          
      

        ]
    })
});

</script>


<script>
$(document).ready(function() {

    $(document).on('change', '.type', function() {
        var id = $(this).val();
  console.log(id);
var sub_category_id = $(this).data('category_id');

 if (id == 'Supplier'){
      $('.item_supplier' + sub_category_id).show();
   $('.item_client' + sub_category_id).hide(); 
    $('.item_user' + sub_category_id).hide();
     

}

else if(id == 'Client'){
        $('.item_client' + sub_category_id).show();   
     $('.item_supplier' + sub_category_id).hide(); 
      $('.item_user' + sub_category_id).hide();
      
}
else if(id == 'User'){
        $('.item_user' + sub_category_id).show(); 
        $('.item_client' + sub_category_id).hide(); 
     $('.item_supplier' + sub_category_id).hide(); 
      
}



else{
    
  $('.item_client' + sub_category_id).hide();    
     $('.item_supplier' + sub_category_id).hide(); 
      $('.item_user' + sub_category_id).hide();

}


     

    });



});

</script>

<script type="text/javascript">
$(document).ready(function() {


    var count = 0;
    
 

    $('.add').on("click", function(e) {

        count++;
        var html = '';
        html += '<tr class="line_items">';
        html +='<td><div><select class="form-control m-b type" id="type' +count + '" name="type[]" data-category_id="' +count + '" required><option value="">Select Type</option><option value="Client">Client</option><option value="Supplier">Supplier</option> <option value="User">Staff</option><option value="Others">Others</option></select></div><br><div class="item_client' + count +'"  id="client" style="display:none;"><select class="form control m-b client_id" id="client_id' + count +'" name="client_id[]"><option value="">Select Client</option> @foreach ($client as $c) <option value="{{$c->id}}" >{{$c->name}}</option>@endforeach</select></div><div class="item_supplier' + count +'"  id="supplier" style="display:none;"><select class="form control m-b supplier_id" id="supplier_id' + count +'" name="supplier_id[]"><option value="">Select Supplier</option> @foreach ($supplier as $m) <option value="{{$m->id}}" >{{$m->name}}</option>@endforeach</select></div><div class="item_user' + count +'"  id="user" style="display:none;"><select class="form control m-b user_id" id="user_id' + count +'" name="user_id[]"><option value="">Select Staff</option> @foreach($user as $u)<option value="{{$u->id}}">{{$u->name}}</option>@endforeach</select></div></td>';
        html +='<td><select class="form control m-b account" id="account_id' + count +'" name="account_id[]" required><option value="">Select Account</option> @foreach($chart_of_accounts as $group => $ch)<optgroup label="{{$group}}"> @foreach($ch as $chart)<option value="{{$chart->id}}">{{$chart->account_name}}</option>@endforeach</optgroup> @endforeach</select>  </td>';
        html +='<td><input type="text" name="debit[]" class="form-control debit" id="debit' + count +'"  data-category_id="' +count + '" value=""/></td>';
        html +='<td><input type="text" name="credit[]" class="form-control credit" id="credit' + count +'"   data-category_id="' +count + '" value="" /></td>';
        html +='<td><textarea name="notes[]" placeholder="" class="form-control" rows="2"></textarea></td>';
        html +='<td><button type="button" name="remove" class="btn btn-danger btn-xs remove"><i class="icon-trash"></i></button></td>';
        
        

        $('#cart > tbody').append(html);
      
            $(".m-b").select2({
                            });
                            
                            
                            
           $('.debit').keyup(function(event) {   
// skip for arrow keys
  if(event.which >= 37 && event.which <= 40){
   //event.preventDefault();
  }

  $(this).val(function(index, value) {
      
      value = value.replace(/[^0-9\.]/g, ""); // remove commas from existing input
      return numberWithCommas(value); // add commas back in
      
  });
});                 
          

$('.credit').keyup(function(event) {   
// skip for arrow keys
 if(event.which >= 37 && event.which <= 40){
   //event.preventDefault();
  }

  $(this).val(function(index, value) {
      value = value.replace(/[^0-9\.]/g, ""); // remove commas from existing input
      return numberWithCommas(value); // add commas back in
  });
});    


      
    });
    
    
    
 
});
</script>




<script type="text/javascript"> 
$(document).on("change", function () {
var total_dr=0;
var total_cr=0;
var sum=0;

 $(".debit").each(function () {
         total_dr += +$(this).val().replace(/,/ig, '');
    $(".total_debit").html(numberWithCommas(total_dr));
        });

  $(".credit").each(function () {
         total_cr += +$(this).val().replace(/,/ig, '');
    $(".total_credit").html(numberWithCommas(total_cr));
        });
        
    sum=total_dr-total_cr; 
    var x=Math.abs(sum);
    $(".total_diff").html(numberWithCommas(x));
    
     
        $('.remove').on("click", function(e) {  
            
             $(this).closest('tr').remove();
             
             $(".total_diff").html(numberWithCommas(x)).change();
        
    });
   

});
</script>

<script>
    $(document).ready(function() {
    
       $(document).on('change', '.debit', function() {
        var category_id = $(this).data('category_id');
        
        console.log(category_id);
        $('#credit' + category_id).val(0);
    
        });
        
         $(document).on('change', '.credit', function() {
        var category_id = $(this).data('category_id');
        console.log(category_id);
        $('#debit' + category_id).val(0);
    
        });
        
         
        
         $(document).on('click', '.save', function(event) {
         var x=$(".total_diff").html();
         
         $('.errors').empty();
        
         if(x == '0'){
          
             
         }
         
         else{
             event.preventDefault(); 
          $('.errors').append('The Journal must balance (Debits equal to Credits).');
          
         }
        
    });
    
    
    
    });
    </script>
    
    


<script type="text/javascript">


function numberWithCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}

</script>





@endsection