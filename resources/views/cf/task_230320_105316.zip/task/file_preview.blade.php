<form id="addRtwForm" method="post" action="javascript:void(0)">

         
                 
               <iframe id="inlineFrameExample" width="100%"  height="700px"
                title="Inline Frame Example"  src="{{url('public/project')}}/{{$filename}}">
            </iframe> 
           
</form>