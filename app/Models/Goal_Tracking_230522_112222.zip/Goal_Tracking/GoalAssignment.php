<?php

namespace App\Models\Goal_Tracking;

use Illuminate\Database\Eloquent\Model;

class GoalAssignment extends Model
{
    protected $table = "tbl_goal_assignment";

    protected $guarded = ['id'];

}