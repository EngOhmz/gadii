<?php

namespace App\Models\Goal_Tracking;

use Illuminate\Database\Eloquent\Model;

class TaskAssignment extends Model
{
    protected $table = "tbl_goal_task_assignment";

    protected $guarded = ['id'];

}