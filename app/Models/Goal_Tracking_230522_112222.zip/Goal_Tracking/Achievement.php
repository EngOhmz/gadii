<?php

namespace App\Models\Goal_Tracking;

use Illuminate\Database\Eloquent\Model;

class Achievement extends Model
{
    protected $table = "tbl_achievement";

    protected $guarded = ['id'];
    
   



}