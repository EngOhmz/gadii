<?php

namespace App\Models\Goal_Tracking;

use Illuminate\Database\Eloquent\Model;

class GoalTracking extends Model
{
    protected $table = "tbl_goal_tracking";

    protected $guarded = ['id'];
    
   



}