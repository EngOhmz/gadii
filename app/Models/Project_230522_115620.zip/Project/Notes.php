<?php

namespace App\Models\Project;

use Illuminate\Database\Eloquent\Model;

class Notes extends Model
{
    protected $table = "tbl_project_notes";

    protected $guarded = ['id'];
    
   



}