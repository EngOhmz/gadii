<?php

namespace App\Models\Leads;

use Illuminate\Database\Eloquent\Model;

class LeadStatus extends Model
{
    protected $table = "tbl_lead_status";

    protected $guarded = ['id'];
    
   
    



}
