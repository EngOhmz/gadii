<?php

namespace App\Models\Leads;

use Illuminate\Database\Eloquent\Model;

class LeadSource extends Model
{
    protected $table = "tbl_lead_source";

    protected $guarded = ['id'];
    
  
    



}
