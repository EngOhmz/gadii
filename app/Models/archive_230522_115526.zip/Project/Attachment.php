<?php

namespace App\Models\Project;

use Illuminate\Database\Eloquent\Model;

class Attachment extends Model
{
    protected $table = "tbl_project_attachment";

    protected $guarded = ['id'];
    
   



}