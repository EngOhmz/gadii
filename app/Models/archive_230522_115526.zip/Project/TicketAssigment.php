<?php

namespace App\Models\Project;

use Illuminate\Database\Eloquent\Model;

class TicketAssigment extends Model
{
    protected $table = "tbl_ticket_assignment";

    protected $guarded = ['id'];
    
    

}
