<?php

namespace App\Http\Controllers\Management;


use App\Http\Controllers\Controller;

use App\Models\Management\Car;
use Illuminate\Http\Request;

class CarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $cars = Car::all();

        return view('management.add_car', compact('cars'));


    }

    public function arrived(){
        // $cars = Car::all();

        $cars = Car::where('status', 1)->get();


        return view('management.arrived_car', compact('cars'));


    }

    public function all(){
        $cars = Car::all();

        return view('management.all_car', compact('cars'));


    }

    public function old(){
        $cars = Car::all();

        return view('management.old_car', compact('cars'));


    }

    public function car_routes(){
        $cars = Car::all();

        return view('management.car_routes', compact('cars'));


    }

    public function car_pacel(){
        $cars = Car::all();

        return view('management.car_pacels', compact('cars'));


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $this->validate($request,[
            'carNumber'=>'required'
        ]); 
        
      
        $car= new Car();

        $car->carNumber=$request->input('carNumber');
        $car->status=1;


        $car->save();

        return redirect()->route('car.index')->with('success', 'Saved Successfully');


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Management\Car  $car
     * @return \Illuminate\Http\Response
     */
    public function show(Car $car)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Management\Car  $car
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $car = Car::find($id);

        return view('management.edit_car', compact('car'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Management\Car  $car
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Car $car)
    {
        //
        $this->validate($request,[
            'carNumber'=>'required'
        ]); 
        
      
        $car->update($request->all());

        return redirect()->route('car.index')->with('success', 'Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Management\Car  $car
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $data=Car::find($id);
        $data->delete();

        return redirect()->route('car.index')->with('success', 'Deleted Successfully');

    }
}
