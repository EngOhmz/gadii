<?php
namespace App\Http\Controllers\Api_controllers;

use App\Http\Controllers\Controller;
use App\Models\Customer\Customer;
use App\Models\Customer\CustomerPacel;
use App\Models\Management\Car;
use App\Models\Management\Driver;
use App\Models\PackageLoad;
use App\Models\UserCarSelection;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ManagementController extends Controller
{
    //
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function pacel(String $date)
    {
        //
        $pacels = CustomerPacel::whereDate('created_at', $date)->get();
        // $mizigo = $pacels->count();

       
        
        if($pacels->isEmpty()){

            $data['mizigo'] = 0;

            $data['jumla_gari'] = 0;

            $data['mizigo_gari'] = 0;

            $farmers = $data;

            $response=['success'=>true,'error'=>false,'message'=>'successfully','pacels'=>$farmers];

            return response()->json($response,200);
                
        }
        else{

                $data['mizigo'] = CustomerPacel::whereDate('created_at', $date)->count();

                $jumla_gari = Car::whereDate('created_at', $date)->get();

                if($jumla_gari->isEmpty()){

                    $data['jumla_gari'] = 0;

                }
                else{

                    $data['jumla_gari'] = Car::whereDate('created_at', $date)->count();

                }

                $mizigo_gari = Car::where('status', 2)->whereDate('created_at', $date)->get();

                if($mizigo_gari->isEmpty()){

                    $data['mizigo_gari'] = 0;
                    
                }
                else{
                    $data['mizigo_gari'] = Car::where('status', 2)->whereDate('created_at', $date)->count();


                }


                $farmers = $data;
     
           

            $response=['success'=>true,'error'=>false,'message'=>'successfully','pacels'=>$farmers];
            return response()->json($response,200);
        } 
    }

    public function pacel_today(String $date)
    {
        //
        $today = Carbon::today();
        $pacels = CustomerPacel::whereDate('created_at', $date)->get();
        // $mizigo = $pacels->count();

        if($pacels->isEmpty()){

            $response=['success'=>false,'error'=>true,'message'=>'No Pacels found on that date'];
            return response()->json($response,200);

            
        }
        
        else{

            foreach($pacels as $row){

                
                $data['id'] = $row->id;
                $data['name'] = $row->name;
                $data['idadi'] = $row->idadi;

                $customer = Customer::where('id', $row->pacel_id)->get();

                foreach($customer as $row2){

                $data['mteja'] = $row2->mteja;

                }

                $data['mzigo_unapotoka'] = $row->mzigo_unapotoka;
                $data['created_at'] = $row->created_at;
                $data['mzigo_unapokwenda'] = $row->mzigo_unapokwenda;
                $data['jumla'] = $row->jumla;
                $data['ela_iliyopokelewa'] = $row->ela_iliyopokelewa;


                $farmers[] = $data;
            }

            $response=['success'=>true,'error'=>false,'message'=>'successfully','pacels'=>$farmers];
            return response()->json($response,200);
        }
    }

    public function car_today(int $id, String $date)
    {
        //
        $today = Carbon::today();
        $carSelected = UserCarSelection::where('user_id', $id)->whereDate('created_at', $date)->get();
        
        // $pacels = Car::where()->whereDate('created_at', $date)->get();
        // $mizigo = $pacels->count();

        if($carSelected->isEmpty()){

            $response=['success'=>false,'error'=>true,'message'=>'No Cars found with that user id'];
            return response()->json($response,200);

            
        }
        
        else{

            foreach($carSelected as $row){

                $car = Car::find($row->car_id);
             
                $data['carNumber'] = $car->carNumber;
                $data['id'] = $car->id;
                $driver = Driver::where('id', $car->driver_id)->value('name');
                $data['driver'] = $driver;


                $farmers = $data;
            }

            $response=['success'=>true,'error'=>false,'message'=>'successfully','car'=>$farmers];
            return response()->json($response,200);
        }
    }


    public function driver(String $date)
    {
        //
        $drivers = Driver::whereDate('assigned_date', $date)->get();
        // $mizigo = $pacels->count();

       
        
        if($drivers->isEmpty()){

            $response=['success'=>false,'error'=>true,'message'=>'No driver found on that date'];
            return response()->json($response,200);

            
        }
        else{

            foreach($drivers as $row){
                
                $data['id'] = $row->id;
                

                $data['name'] = $row->name;
                $phone = $row->phone;
                if(empty($phone)){

                    $data['phone'] = "no phone registerd";

                }
                else{

                    $data['phone'] = $row->phone;

 
                }

                if( $row->status == '2'){

                $data['status'] = "Assigned";

                }
                elseif( $row->status == '1'){

                $data['status'] = "Not Assigned";

                }
                else{

                    $data['status'] = "Start offload";
    
                    }

                $farmers[] = $data;
            }

            $response=['success'=>true,'error'=>false,'message'=>'successfully','drivers'=>$farmers];
            return response()->json($response,200);

            
        } 
    }

    public function car()
    {
        //
        $cars = Car::all();
        // $mizigo = $pacels->count();

       
        
        if($cars->isEmpty()){

            $response=['success'=>false,'error'=>true,'message'=>'No Cars found'];
            return response()->json($response,200);

            
        }
        else{

            foreach($cars as $row){

                $data['id'] = $row->id;


                $data['carNumber'] = $row->carNumber;
                //driver_id

                $driver_id = $row->driver_id;
                if(empty($driver_id)){
                    $data['driver'] = 'null';
                }
                else{
                    $driver =  Driver::find($driver_id);
                    
                    $data['driver'] = $driver->name;
                    

                }


                if( $row->status == '1'){

                $data['status'] = "inasubiri";

                }
                elseif( $row->status == '2'){

                $data['status'] = "inapakiwa";

                }
                elseif( $row->status == '3'){

                    $data['status'] = "imefungwa";
    
                    }
                else{

                    $data['status'] = "kushusha";
    
                    }

                $farmers[] = $data;
            }

            $response=['success'=>true,'error'=>false,'message'=>'successfully','cars'=>$farmers];
            return response()->json($response,200);

            
        } 
    }

    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    public function driver_store(Request $request)
    {
        
        $this->validate($request,[
            'name'=>'required',

        ]); 
        
        //$data=$this->request();
        //$data['user_id'] =auth()->user()->id;
        //$farmer= Farmer::create($data);
      
        $farmer= new Driver();

        $farmer->name=$request->input('name');
        $farmer->phone=$request->input('phone');
        $farmer->assigned_date = Carbon::now()->format('Y-m-d');
        $farmer->status = 1;
        $farmer->save();
        if($farmer)
        {
            $response=['success'=>true,'error'=>false,'message'=>'New Driver registered successful'];
            return response()->json($response,200);
        }
        else
        {
            $response=['success'=>false,'error'=>true,'message'=>'Failed to register new Driver'];
            return response()->json($response,200);
        }

        //return view('manage-farmer');
    }

    public function car_store(Request $request)
    {
        
        $this->validate($request,[
            'carNumber'=>'required',

        ]); 
        
        //$data=$this->request();
        //$data['user_id'] =auth()->user()->id;
        //$farmer= Farmer::create($data);
      
        $farmer= new Car();

        $farmer->carNumber=$request->input('carNumber');
        $farmer->status = 1;
        $farmer->save();
        if($farmer)
        {
            $response=['success'=>true,'error'=>false,'message'=>'New Car registered successful'];
            return response()->json($response,200);
        }
        else
        {
            $response=['success'=>false,'error'=>true,'message'=>'Failed to register new  Car'];
            return response()->json($response,200);
        }

        //return view('manage-farmer');
    }

    public function car_selection(Request $request)
    {
        
        $this->validate($request,[
            'user_id'=>'required',
            'car_id'=>'required',


        ]); 
        
        //$data=$this->request();
        //$data['user_id'] =auth()->user()->id;
        //$farmer= Farmer::create($data);
      
        $farmer= new UserCarSelection();

        $farmer->user_id=$request->input('user_id');
        $farmer->car_id=$request->input('car_id');
        $farmer->save();
        if($farmer)
        {
            $response=['success'=>true,'error'=>false,'message'=>'New Car selected  successful'];
            return response()->json($response,200);
        }
        else
        {
            $response=['success'=>false,'error'=>true,'message'=>'Failed to select Car successful'];
            return response()->json($response,200);
        }

        //return view('manage-farmer');
    }

    public function packing_store(Request $request)
    {
        
        $this->validate($request,[
            'user_id'=>'required',
            'car_id'=>'required',
            'pacel_id'=>'required',
            'idadi'=>'required',
            'price'=>'required'


        ]); 
        
        //$data=$this->request();
        //$data['user_id'] =auth()->user()->id;
        //$farmer= Farmer::create($data);
      
        $farmer= new PackageLoad();

        $farmer->user_id=$request->input('user_id');
        $farmer->car_id=$request->input('car_id');
        $farmer->pacel_id=$request->input('pacel_id');
        $farmer->idadi=$request->input('idadi');
        $farmer->price=$request->input('price');
        $farmer->save();
        if($farmer)
        {
            $response=['success'=>true,'error'=>false,'message'=>'Package packing  successful'];
            return response()->json($response,200);
        }
        else
        {
            $response=['success'=>false,'error'=>true,'message'=>'Failed to pack Package successful'];
            return response()->json($response,200);
        }

        //return view('manage-farmer');
    }

    

    public function driver_assign(int $driver_id, int $car_id)
    {
        
      
        $driver =  Driver::where('id', $driver_id)->update(['status' => '2']);

        $car =  Car::where('id', $car_id)->update(['driver_id' => $driver_id]);

        if($driver)
        {
            if($car){
                $response=['success'=>true,'error'=>false,'message'=>'Driver Assigned car successful'];
                return response()->json($response,200);
            }
            else{
                $response=['success'=>false,'error'=>true,'message'=>'Car Failed to be Assigned successful cause of car id'];
                return response()->json($response,200);
            }
            
        }
        else
        {
            $response=['success'=>false,'error'=>true,'message'=>'Failed to Driver Assigned Car'];
            return response()->json($response,200);
        }

        //return view('manage-farmer');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
